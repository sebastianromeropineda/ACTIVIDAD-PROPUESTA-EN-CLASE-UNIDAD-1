package co.edu.ude.poo.investigacion;

import co.edu.ude.poo.investigacion.modelo.entidades.*;

public class Principal {
    public static void main(String[] args) {
        Investigador principal = new Investigador("Sebastián Romero", "Docente", "Institución X");
        Investigador coinvestigador = new Investigador("Ana López", "Estudiante", "Institución Y");

        Actividad actividad = new Actividad("Desarrollo de algoritmo de categorización", "30 días");
        actividad.setResponsable(principal);
        actividad.agregarCoinvestigador(coinvestigador);

        Producto producto = new Producto("Software educativo", "Desarrollo de herramienta para categorizar investigadores", "Publicado", "software_edu.pdf", "2025-04-22", "A", 10);
        producto.agregarActividad(actividad);

        System.out.println(principal);
        System.out.println(actividad);
        System.out.println(producto);
    }
}