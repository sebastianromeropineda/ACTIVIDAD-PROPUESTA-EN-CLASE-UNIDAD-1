package co.edu.ude.poo.investigacion.modelo.entidades;

import java.util.ArrayList;
import java.util.List;

public class Producto {
    private String nombre;
    private String descripcion;
    private String estado;
    private String documento;
    private String fechaPublicacion;
    private String categoria;
    private int puntos;
    private List<Actividad> actividades;

    public Producto() {
        this.actividades = new ArrayList<>();
    }

    public Producto(String nombre, String descripcion, String estado, String documento, String fecha, String categoria, int puntos) {
        this();
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.estado = estado;
        this.documento = documento;
        this.fechaPublicacion = fecha;
        this.categoria = categoria;
        this.puntos = puntos;
    }

    public void agregarActividad(Actividad actividad) {
        this.actividades.add(actividad);
    }

    @Override
    public String toString() {
        return "Producto de Investigación:\nNombre: " + nombre + "\nDescripción: " + descripcion +
               "\nEstado: " + estado + "\nDocumento: " + documento + "\nFecha Publicación: " +
               fechaPublicacion + "\nCategoría: " + categoria + "\nPuntos: " + puntos +
               "\nActividades asociadas: " + actividades.size();
    }
}