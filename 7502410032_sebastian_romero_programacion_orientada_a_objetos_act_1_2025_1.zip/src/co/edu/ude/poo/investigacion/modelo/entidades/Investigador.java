package co.edu.ude.poo.investigacion.modelo.entidades;

public class Investigador {
    private String nombre;
    private String rol;
    private String institucion;

    public Investigador() {}

    public Investigador(String nombre, String rol, String institucion) {
        this.nombre = nombre;
        this.rol = rol;
        this.institucion = institucion;
    }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getRol() { return rol; }
    public void setRol(String rol) { this.rol = rol; }

    public String getInstitucion() { return institucion; }
    public void setInstitucion(String institucion) { this.institucion = institucion; }

    @Override
    public String toString() {
        return "Investigador:\nNombre: " + nombre + "\nRol: " + rol + "\nInstitución: " + institucion;
    }
}