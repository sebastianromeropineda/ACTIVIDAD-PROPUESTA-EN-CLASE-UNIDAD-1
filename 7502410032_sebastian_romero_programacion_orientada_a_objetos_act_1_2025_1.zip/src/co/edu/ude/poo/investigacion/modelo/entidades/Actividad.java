package co.edu.ude.poo.investigacion.modelo.entidades;

import java.util.ArrayList;
import java.util.List;

public class Actividad {
    private String descripcion;
    private String duracion;
    private Investigador responsable;
    private List<Investigador> coinvestigadores;

    public Actividad() {
        this.coinvestigadores = new ArrayList<>();
    }

    public Actividad(String descripcion, String duracion) {
        this.descripcion = descripcion;
        this.duracion = duracion;
        this.coinvestigadores = new ArrayList<>();
    }

    public void setResponsable(Investigador responsable) {
        this.responsable = responsable;
    }

    public void agregarCoinvestigador(Investigador coinvestigador) {
        this.coinvestigadores.add(coinvestigador);
    }

    @Override
    public String toString() {
        return "Actividad:\nDescripción: " + descripcion + "\nDuración: " + duracion +
               "\nResponsable: " + responsable.getNombre() +
               "\nCoinvestigadores: " + coinvestigadores.size();
    }
}